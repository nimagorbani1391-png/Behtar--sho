@echo off
setlocal
set PROJECT_DIR=%~dp0
set GRADLE_HOME_DIR=%USERPROFILE%\.gradle\manual\gradle-8.9
if not exist "%GRADLE_HOME_DIR%\bin\gradle.bat" (
  echo Gradle 8.9 is not installed. Downloading it now...
  powershell -NoProfile -ExecutionPolicy Bypass -File "%PROJECT_DIR%setup-gradle.ps1"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_HOME_DIR%\bin\gradle.bat" -p "%PROJECT_DIR%" %*
exit /b %ERRORLEVEL%
