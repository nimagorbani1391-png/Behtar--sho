package com.nima.behtarsho.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

@Entity(tableName = "challenges")
data class ChallengeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val goal: String,
    val durationDays: Int,
    val startEpochDay: Long,
    val isActive: Boolean = true
) {
    val endExclusiveEpochDay: Long get() = startEpochDay + durationDays
}

@Entity(
    tableName = "completions",
    indices = [Index(value = ["epochDay"], unique = true)]
)
data class CompletionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val epochDay: Long,
    val challengeId: Long
)

@Dao
interface ChallengeDao {
    @Query("SELECT * FROM challenges WHERE isActive = 1 ORDER BY id DESC LIMIT 1")
    fun observeActiveChallenge(): Flow<ChallengeEntity?>

    @Query("SELECT * FROM challenges WHERE isActive = 1 ORDER BY id DESC LIMIT 1")
    suspend fun getActiveChallenge(): ChallengeEntity?

    @Query("SELECT COUNT(*) * 5 FROM completions")
    fun observeTotalPoints(): Flow<Int>

    @Query("SELECT epochDay FROM completions")
    fun observeCompletionDays(): Flow<List<Long>>

    @Query("UPDATE challenges SET isActive = 0 WHERE isActive = 1")
    suspend fun deactivateCurrentChallenge()

    @Insert
    suspend fun insertChallenge(challenge: ChallengeEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCompletion(completion: CompletionEntity): Long
}

@Database(
    entities = [ChallengeEntity::class, CompletionEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun challengeDao(): ChallengeDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "behtar_sho_local.db"
                ).build().also { INSTANCE = it }
            }
    }
}

sealed interface CompletionResult {
    data object Success : CompletionResult
    data object AlreadyCompleted : CompletionResult
    data object NoChallenge : CompletionResult
    data object ChallengeExpired : CompletionResult
}

class ChallengeRepository(context: Context) {
    private val database = AppDatabase.getInstance(context)
    private val dao = database.challengeDao()

    val activeChallenge: Flow<ChallengeEntity?> = dao.observeActiveChallenge()
    val totalPoints: Flow<Int> = dao.observeTotalPoints()
    val completionDays: Flow<List<Long>> = dao.observeCompletionDays()

    suspend fun createChallenge(title: String, goal: String, durationDays: Int) {
        val today = LocalDate.now().toEpochDay()
        database.withTransaction {
            dao.deactivateCurrentChallenge()
            dao.insertChallenge(
                ChallengeEntity(
                    title = title.trim(),
                    goal = goal.trim(),
                    durationDays = durationDays,
                    startEpochDay = today,
                    isActive = true
                )
            )
        }
    }

    suspend fun completeToday(): CompletionResult {
        val today = LocalDate.now().toEpochDay()
        return database.withTransaction {
            val challenge = dao.getActiveChallenge() ?: return@withTransaction CompletionResult.NoChallenge
            if (today < challenge.startEpochDay || today >= challenge.endExclusiveEpochDay) {
                return@withTransaction CompletionResult.ChallengeExpired
            }
            val insertedId = dao.insertCompletion(
                CompletionEntity(epochDay = today, challengeId = challenge.id)
            )
            if (insertedId == -1L) CompletionResult.AlreadyCompleted else CompletionResult.Success
        }
    }
}
