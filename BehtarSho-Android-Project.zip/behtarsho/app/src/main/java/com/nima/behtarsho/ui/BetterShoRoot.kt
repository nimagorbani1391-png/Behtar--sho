package com.nima.behtarsho.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material.icons.outlined.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.ui.text.style.TextOverflow
import kotlinx.coroutines.flow.collectLatest

private enum class AppScreen { HOME, CUPS, SETTINGS, CHALLENGE_FORM, VIP }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BetterShoRoot(viewModel: AppViewModel) {
    val state by viewModel.uiState.collectAsState()
    val snackbarHost = remember { SnackbarHostState() }
    var screen by rememberSaveable { mutableStateOf(AppScreen.HOME.name) }
    var vipReturnScreen by rememberSaveable { mutableStateOf(AppScreen.SETTINGS.name) }
    val currentScreen = runCatching { AppScreen.valueOf(screen) }.getOrDefault(AppScreen.HOME)

    LaunchedEffect(viewModel) {
        viewModel.messages.collectLatest { snackbarHost.showSnackbar(it) }
    }

    BehtarShoTheme(darkTheme = state.darkMode) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                when {
                    state.isLoading -> LoadingScreen()
                    state.userName.isBlank() -> NameEntryScreen(onSave = viewModel::saveName)
                    else -> {
                        val primaryScreen = currentScreen in setOf(AppScreen.HOME, AppScreen.CUPS, AppScreen.SETTINGS)
                        Scaffold(
                            topBar = {
                                TopAppBar(
                                    title = {
                                        Text(
                                            when (currentScreen) {
                                                AppScreen.HOME -> "بهتر شو"
                                                AppScreen.CUPS -> "کاپ‌های من"
                                                AppScreen.SETTINGS -> "تنظیمات"
                                                AppScreen.CHALLENGE_FORM -> "ساخت چالش"
                                                AppScreen.VIP -> "اشتراک VIP"
                                            },
                                            fontWeight = FontWeight.Bold
                                        )
                                    },
                                    navigationIcon = {
                                        if (!primaryScreen) {
                                            androidx.compose.material3.IconButton(onClick = {
                                                screen = if (currentScreen == AppScreen.VIP) vipReturnScreen else AppScreen.HOME.name
                                            }) {
                                                Icon(Icons.Filled.ArrowBack, contentDescription = "بازگشت")
                                            }
                                        }
                                    },
                                    colors = TopAppBarDefaults.topAppBarColors(
                                        containerColor = MaterialTheme.colorScheme.background,
                                        titleContentColor = MaterialTheme.colorScheme.onBackground
                                    )
                                )
                            },
                            bottomBar = {
                                if (primaryScreen) {
                                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                                        NavigationBarItem(
                                            selected = currentScreen == AppScreen.HOME,
                                            onClick = { screen = AppScreen.HOME.name },
                                            icon = { Icon(Icons.Filled.Home, contentDescription = null) },
                                            label = { Text("خانه") }
                                        )
                                        NavigationBarItem(
                                            selected = currentScreen == AppScreen.CUPS,
                                            onClick = { screen = AppScreen.CUPS.name },
                                            icon = { Icon(Icons.Filled.EmojiEvents, contentDescription = null) },
                                            label = { Text("کاپ‌ها") }
                                        )
                                        NavigationBarItem(
                                            selected = currentScreen == AppScreen.SETTINGS,
                                            onClick = { screen = AppScreen.SETTINGS.name },
                                            icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                                            label = { Text("تنظیمات") }
                                        )
                                    }
                                }
                            },
                            snackbarHost = { SnackbarHost(snackbarHost) },
                            containerColor = MaterialTheme.colorScheme.background
                        ) { padding ->
                            Box(Modifier.padding(padding).fillMaxSize()) {
                                when (currentScreen) {
                                    AppScreen.HOME -> HomeScreen(
                                        state = state,
                                        onCreateChallenge = { screen = AppScreen.CHALLENGE_FORM.name },
                                        onComplete = viewModel::completeToday,
                                        onOpenVip = { vipReturnScreen = AppScreen.HOME.name; screen = AppScreen.VIP.name }
                                    )
                                    AppScreen.CUPS -> CupsScreen(totalPoints = state.totalPoints)
                                    AppScreen.SETTINGS -> SettingsScreen(
                                        darkMode = state.darkMode,
                                        onDarkModeChange = viewModel::setDarkMode,
                                        onOpenVip = { vipReturnScreen = AppScreen.SETTINGS.name; screen = AppScreen.VIP.name }
                                    )
                                    AppScreen.CHALLENGE_FORM -> ChallengeFormScreen(
                                        onCreate = { title, goal, days ->
                                            viewModel.createChallenge(title, goal, days)
                                            screen = AppScreen.HOME.name
                                        }
                                    )
                                    AppScreen.VIP -> VipScreen(onPurchase = {
                                        viewModel.messages.tryEmit("خرید اشتراک VIP به‌زودی فعال می‌شود!")
                                    })
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LoadingScreen() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text("بهتر شو", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun NameEntryScreen(onSave: (String) -> Unit) {
    var name by rememberSaveable { mutableStateOf("") }
    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier.size(84.dp).clip(RoundedCornerShape(28.dp)).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Star, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(42.dp))
        }
        Spacer(Modifier.height(24.dp))
        Text("بهتر شو", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(8.dp))
        Text("هر روز، فقط یک قدم رو به جلو.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(36.dp))
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("اسمت چیه؟") },
            singleLine = true,
            shape = RoundedCornerShape(16.dp)
        )
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { onSave(name) },
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(16.dp)
        ) { Text("شروع کنیم", fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(14.dp))
        Text("فقط نامت ذخیره می‌شه؛ ثبت‌نام و رمز عبور نداری.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}

@Composable
private fun HomeScreen(
    state: AppUiState,
    onCreateChallenge: () -> Unit,
    onComplete: () -> Unit,
    onOpenVip: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("سلام ${state.userName} 👋", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("برای بهتر شدن، همین امروز یک قدم بردار.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("امتیاز کل", color = Color.White.copy(alpha = 0.82f), style = MaterialTheme.typography.titleSmall)
                    Text("${state.totalPoints.toPersianDigits()} امتیاز", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                    Text("هر روز موفق = ۵ امتیاز", color = Color.White.copy(alpha = 0.82f), style = MaterialTheme.typography.bodySmall)
                }
                Box(
                    modifier = Modifier.size(58.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.EmojiEvents, contentDescription = null, tint = Color(0xFFFFD58C), modifier = Modifier.size(34.dp))
                }
            }
        }

        val challenge = state.challenge
        if (challenge == null) {
            ElevatedCard(shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("هنوز چالشی نساختی", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("یک هدف انتخاب کن و برای انجام روزانه‌اش متعهد شو.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = onCreateChallenge, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(15.dp)) {
                        Icon(Icons.Filled.Add, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("ساخت چالش جدید", fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            ElevatedCard(shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("چالش فعلی", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                        Text("${challenge.durationDays.toPersianDigits()} روز", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
                    }
                    Text(challenge.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(challenge.goal, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("روز چالش", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${state.challengeDayNumber.coerceAtMost(challenge.durationDays).toPersianDigits()} از ${challenge.durationDays.toPersianDigits()}", fontWeight = FontWeight.SemiBold)
                    }
                    when {
                        state.challengeExpired -> {
                            Text("مدت این چالش به پایان رسیده.", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Medium)
                            Button(onClick = onCreateChallenge, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(15.dp)) {
                                Text("ساخت چالش جدید", fontWeight = FontWeight.Bold)
                            }
                        }
                        state.completedToday -> {
                            Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth()) {
                                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Spacer(Modifier.width(9.dp))
                                    Column {
                                        Text("امروز انجام شد", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                        Text("فردا منتظریم، با همین انرژی ادامه بده! 🔥", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                    }
                                }
                            }
                        }
                        else -> {
                            Button(onClick = onComplete, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp)) {
                                Icon(Icons.Filled.CheckCircle, contentDescription = null)
                                Spacer(Modifier.width(9.dp))
                                Text("وظیفه امروزم رو انجام دادم", fontWeight = FontWeight.Bold)
                            }
                            Text("با ثبت انجام امروز، ۵ امتیاز می‌گیری.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
            }
        }

        OutlinedButton(
            onClick = onOpenVip,
            modifier = Modifier.fillMaxWidth().height(58.dp),
            shape = RoundedCornerShape(18.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Icon(Icons.Outlined.NotificationsActive, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
            Spacer(Modifier.width(10.dp))
            Column(horizontalAlignment = Alignment.Start) {
                Text("یادآوری روزانه با VIP", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                Text("قابلیت ویژه و فعلاً غیرفعال", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.weight(1f))
            Icon(Icons.Filled.Lock, contentDescription = "قفل", tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(4.dp))
    }
}

private data class CupInfo(val name: String, val points: Int, val subtitle: String)

@Composable
private fun CupsScreen(totalPoints: Int) {
    val cups = listOf(
        CupInfo("با ثبات 💪🏻", 20, "اولین قدم‌های پیوسته"),
        CupInfo("کاپ ۴۰ امتیازی", 40, "ادامه دادن ارزشمنده"),
        CupInfo("کاپ ۶۰ امتیازی", 60, "ثباتت رو حفظ کن"),
        CupInfo("کاپ ۸۰ امتیازی", 80, "به هدفت نزدیک شدی"),
        CupInfo("کاپ طلایی 🥇", 100, "۱۰۰ امتیاز؛ عالیه!")
    )
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        Text("مسیر پیشرفتت", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("با امتیازهای روزانه، کاپ‌ها یکی‌یکی باز می‌شن.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        cups.forEachIndexed { index, cup ->
            val unlocked = totalPoints >= cup.points
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(19.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (unlocked) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                ),
                border = if (unlocked) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.75f))
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        Modifier.size(54.dp).clip(RoundedCornerShape(17.dp)).background(
                            if (unlocked) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant
                        ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (unlocked) {
                            Icon(Icons.Filled.EmojiEvents, contentDescription = null, tint = if (index == 4) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp))
                        } else {
                            Icon(Icons.Filled.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(25.dp))
                        }
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(cup.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text(cup.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        Text("نیازمند ${cup.points.toPersianDigits()} امتیاز", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                    }
                    Text(if (unlocked) "باز شد" else "قفل", color = if (unlocked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text("امتیاز فعلی: ${totalPoints.toPersianDigits()}", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun SettingsScreen(darkMode: Boolean, onDarkModeChange: (Boolean) -> Unit, onOpenVip: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("ظاهر برنامه", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Card(shape = RoundedCornerShape(19.dp), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(if (darkMode) Icons.Outlined.DarkMode else Icons.Outlined.LightMode, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(27.dp))
                Spacer(Modifier.width(13.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (darkMode) "حالت شب" else "حالت روز", fontWeight = FontWeight.Bold)
                    Text("تغییر رنگ‌بندی برنامه", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = darkMode, onCheckedChange = onDarkModeChange)
            }
        }
        Text("اشتراک", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        OutlinedButton(onClick = onOpenVip, modifier = Modifier.fillMaxWidth().height(60.dp), shape = RoundedCornerShape(17.dp)) {
            Icon(Icons.Outlined.WorkspacePremium, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
            Spacer(Modifier.width(10.dp))
            Text("مشاهده اشتراک VIP", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun ChallengeFormScreen(onCreate: (String, String, String) -> Unit) {
    var title by rememberSaveable { mutableStateOf("") }
    var goal by rememberSaveable { mutableStateOf("") }
    var duration by rememberSaveable { mutableStateOf("") }
    var localError by rememberSaveable { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(15.dp)
    ) {
        Text("چالش خودت رو تعریف کن", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("یک عنوان، دلیل انجام و مدت مشخص انتخاب کن.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedTextField(
            value = title,
            onValueChange = { title = it; localError = "" },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("عنوان چالش") },
            placeholder = { Text("مثلاً مطالعه روزانه") },
            singleLine = true,
            shape = RoundedCornerShape(15.dp)
        )
        OutlinedTextField(
            value = goal,
            onValueChange = { goal = it; localError = "" },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("هدف از چالش") },
            placeholder = { Text("می‌خوام به چه چیزی برسم؟") },
            minLines = 3,
            maxLines = 4,
            shape = RoundedCornerShape(15.dp)
        )
        OutlinedTextField(
            value = duration,
            onValueChange = { duration = it.filter(Char::isDigit); localError = "" },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("مدت زمان انجام چالش (روز)") },
            placeholder = { Text("مثلاً ۳۰") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            shape = RoundedCornerShape(15.dp)
        )
        if (localError.isNotBlank()) Text(localError, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        Button(
            onClick = {
                val parsed = duration.normalizeDigits().toIntOrNull()
                if (title.isBlank() || goal.isBlank() || parsed == null || parsed <= 0 || parsed > 3650) {
                    localError = "هر سه بخش رو کامل کن و مدت معتبر وارد کن."
                } else onCreate(title, goal, duration)
            },
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(16.dp)
        ) { Text("ذخیره چالش", fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun VipScreen(onPurchase: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            shape = RoundedCornerShape(23.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.WorkspacePremium, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(31.dp))
                    Spacer(Modifier.width(10.dp))
                    Text("VIP", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
                Text(
                    "اگه تو هم همش یادت میره هر روز به وظیفت عمل کنی میتونی با دادن پول یه آدامس اشتراک VIP رو بخری که قابلیت ارسال یادآوری روزانه در زمان مشخص برات فعال بشه ⚡🤩",
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    style = MaterialTheme.typography.bodyLarge,
                    lineHeight = 29.sp
                )
                Button(onClick = onPurchase, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(15.dp)) {
                    Text("خرید اشتراک VIP", fontWeight = FontWeight.Bold)
                }
                Text("خرید در این نسخه هنوز فعال نیست.", color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f), style = MaterialTheme.typography.labelSmall)
            }
        }

        Card(shape = RoundedCornerShape(21.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.NotificationsActive, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                    Spacer(Modifier.width(9.dp))
                    Text("یادآوری روزانه", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(20.dp)) {
                        Text("قفل", modifier = Modifier.padding(horizontal = 11.dp, vertical = 5.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Text("این قابلیت مخصوص اشتراک VIP است و در نسخه فعلی غیرفعال است.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                OutlinedButton(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) {
                    Icon(Icons.Filled.Lock, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("تنظیم ساعت یادآوری در نسخه بعدی فعال می‌شود")
                }
            }
        }
    }
}

private fun Int.toPersianDigits(): String = toString().map { ch ->
    if (ch in '0'..'9') ('۰'.code + (ch.code - '0'.code)).toChar() else ch
}.joinToString("")

private fun String.normalizeDigits(): String = map { ch ->
    when (ch) {
        in '۰'..'۹' -> ('0'.code + ch.code - '۰'.code).toChar()
        in '٠'..'٩' -> ('0'.code + ch.code - '٠'.code).toChar()
        else -> ch
    }
}.joinToString("")
