package com.nima.behtarsho.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.userDataStore by preferencesDataStore(name = "behtar_sho_preferences")

class UserPreferences(private val context: Context) {
    private object Keys {
        val USER_NAME = stringPreferencesKey("user_name")
        val DARK_MODE = booleanPreferencesKey("dark_mode")
    }

    val userName: Flow<String> = context.userDataStore.data.map { it[Keys.USER_NAME].orEmpty() }
    val darkMode: Flow<Boolean> = context.userDataStore.data.map { it[Keys.DARK_MODE] ?: false }

    suspend fun saveName(name: String) {
        context.userDataStore.edit { it[Keys.USER_NAME] = name.trim() }
    }

    suspend fun setDarkMode(enabled: Boolean) {
        context.userDataStore.edit { it[Keys.DARK_MODE] = enabled }
    }
}
