package com.nima.behtarsho.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nima.behtarsho.data.ChallengeEntity
import com.nima.behtarsho.data.ChallengeRepository
import com.nima.behtarsho.data.CompletionResult
import com.nima.behtarsho.data.UserPreferences
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

data class AppUiState(
    val isLoading: Boolean = true,
    val userName: String = "",
    val darkMode: Boolean = false,
    val challenge: ChallengeEntity? = null,
    val totalPoints: Int = 0,
    val completionDays: Set<Long> = emptySet(),
    val todayEpochDay: Long = LocalDate.now().toEpochDay()
) {
    val completedToday: Boolean get() = todayEpochDay in completionDays
    val challengeExpired: Boolean
        get() = challenge != null && todayEpochDay >= challenge.endExclusiveEpochDay
    val challengeDayNumber: Int
        get() = challenge?.let { (todayEpochDay - it.startEpochDay + 1).toInt().coerceAtLeast(1) } ?: 0
    val canCompleteToday: Boolean
        get() = challenge != null && !challengeExpired && todayEpochDay >= challenge.startEpochDay && !completedToday
}

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = ChallengeRepository(application)
    private val preferences = UserPreferences(application)
    private val today = MutableStateFlow(LocalDate.now().toEpochDay())

    val messages = MutableSharedFlow<String>(extraBufferCapacity = 2)

    private val preferenceState = combine(preferences.userName, preferences.darkMode, today) { name, dark, day ->
        Triple(name, dark, day)
    }

    val uiState = combine(
        repository.activeChallenge,
        repository.totalPoints,
        repository.completionDays,
        preferenceState
    ) { challenge, points, days, prefs ->
        AppUiState(
            isLoading = false,
            userName = prefs.first,
            darkMode = prefs.second,
            challenge = challenge,
            totalPoints = points,
            completionDays = days.toSet(),
            todayEpochDay = prefs.third
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppUiState())

    fun refreshDay() {
        today.value = LocalDate.now().toEpochDay()
    }

    fun saveName(name: String) {
        val clean = name.trim()
        if (clean.isBlank()) {
            messages.tryEmit("لطفاً نامت رو وارد کن.")
            return
        }
        viewModelScope.launch { preferences.saveName(clean) }
    }

    fun createChallenge(title: String, goal: String, durationText: String) {
        val days = durationText.normalizeDigits().trim().toIntOrNull()
        if (title.isBlank() || goal.isBlank() || days == null || days <= 0) {
            messages.tryEmit("عنوان، هدف و مدت زمان معتبر رو وارد کن.")
            return
        }
        if (days > 3650) {
            messages.tryEmit("مدت چالش نباید بیشتر از ۳۶۵۰ روز باشه.")
            return
        }
        viewModelScope.launch {
            try {
                repository.createChallenge(title, goal, days)
                messages.emit("چالشت با موفقیت ساخته شد.")
            } catch (_: Exception) {
                messages.emit("ذخیره چالش انجام نشد. دوباره تلاش کن.")
            }
        }
    }

    fun completeToday() {
        refreshDay()
        viewModelScope.launch {
            when (repository.completeToday()) {
                CompletionResult.Success -> messages.emit("فردا منتظریم، با همین انرژی ادامه بده! 🔥")
                CompletionResult.AlreadyCompleted -> messages.emit("وظیفه امروزت رو قبلاً ثبت کردی.")
                CompletionResult.NoChallenge -> messages.emit("اول یک چالش بساز.")
                CompletionResult.ChallengeExpired -> messages.emit("مدت این چالش به پایان رسیده.")
            }
        }
    }

    fun setDarkMode(enabled: Boolean) {
        viewModelScope.launch { preferences.setDarkMode(enabled) }
    }

    class Factory(private val application: Application) :
        androidx.lifecycle.ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(AppViewModel::class.java)) {
                return AppViewModel(application) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}

private fun String.normalizeDigits(): String = map { ch ->
    when (ch) {
        in '۰'..'۹' -> ('0'.code + ch.code - '۰'.code).toChar()
        in '٠'..'٩' -> ('0'.code + ch.code - '٠'.code).toChar()
        else -> ch
    }
}.joinToString("")
