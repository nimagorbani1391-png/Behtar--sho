package com.nima.behtarsho.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF286B57),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFDCEFE6),
    onPrimaryContainer = Color(0xFF123B2E),
    secondary = Color(0xFFB47A35),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFFFE8C8),
    onSecondaryContainer = Color(0xFF553500),
    background = Color(0xFFF5F7F3),
    onBackground = Color(0xFF1D2B25),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1D2B25),
    surfaceVariant = Color(0xFFE8EEE9),
    onSurfaceVariant = Color(0xFF526159),
    outline = Color(0xFFD5DED8),
    error = Color(0xFFB3261E)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF80CBB0),
    onPrimary = Color(0xFF073B2C),
    primaryContainer = Color(0xFF174F3D),
    onPrimaryContainer = Color(0xFFBDEBD7),
    secondary = Color(0xFFE7B878),
    onSecondary = Color(0xFF432B08),
    secondaryContainer = Color(0xFF61451E),
    onSecondaryContainer = Color(0xFFFFE2B8),
    background = Color(0xFF101A16),
    onBackground = Color(0xFFE1EAE4),
    surface = Color(0xFF19251F),
    onSurface = Color(0xFFE1EAE4),
    surfaceVariant = Color(0xFF26352D),
    onSurfaceVariant = Color(0xFFB8C8BE),
    outline = Color(0xFF3A4B41),
    error = Color(0xFFF2B8B5)
)

@Composable
fun BehtarShoTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = androidx.compose.material3.Typography(),
        content = content
    )
}
