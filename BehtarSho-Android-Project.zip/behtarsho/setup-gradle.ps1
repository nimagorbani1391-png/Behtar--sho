$ErrorActionPreference = 'Stop'
$version = '8.9'
$root = Join-Path $env:USERPROFILE '.gradle\manual'
$destination = Join-Path $root "gradle-$version"
$archive = Join-Path $root "gradle-$version-bin.zip"
New-Item -ItemType Directory -Force -Path $root | Out-Null
if (-not (Test-Path (Join-Path $destination 'bin\gradle.bat'))) {
    Write-Host "Downloading Gradle $version ..."
    Invoke-WebRequest -Uri "https://services.gradle.org/distributions/gradle-$version-bin.zip" -OutFile $archive
    Expand-Archive -Path $archive -DestinationPath $root -Force
    Remove-Item $archive -Force
}
Write-Host "Gradle $version is ready at: $destination"
